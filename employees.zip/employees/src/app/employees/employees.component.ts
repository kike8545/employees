import {Component, OnInit, ViewChild} from '@angular/core';
import {MatSnackBar} from '@angular/material/snack-bar';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {EmployeesDTO} from '../interfaces/EmployeesDTO';
import {EmployeesService} from '../services/employees.service'
import {InterceptorErrorService} from '../error/interceptor-error.service'

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
  displayedColumns: string[] = ['id', 'first_name', 'last_name', 'mobile_phone', 'edit'];
  dataSource: MatTableDataSource<EmployeesDTO>;
  resultsLength = 0;
  private showLoading: boolean = false;
  private EMPLOYEES: EmployeesDTO[] = [];
  @ViewChild(MatPaginator, {static: false}) set matPaginator(paginator: MatPaginator) {this.dataSource.paginator = paginator;}
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor(
    private _snackBar: MatSnackBar,
    private interceptorErrorService: InterceptorErrorService,
    private employeesService: EmployeesService) {

    // Assign the data to the data source for the table to render
    this.dataSource = new MatTableDataSource([]);
  }
  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  ngOnInit(): void {
    this.findAll();
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  async findAll() {
    this.showLoading = true;
    this.employeesService.findAll()
      .subscribe(employees => {
        this.EMPLOYEES = employees;
        this.dataSource = new MatTableDataSource(this.EMPLOYEES);
        this.resultsLength = this.EMPLOYEES.length;
        this.showLoading = false;
      }, err => {
        this.showLoading = false;
        this.interceptorErrorService.handleError(err);
      });

  }

}
