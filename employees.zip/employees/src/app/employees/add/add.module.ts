import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatCheckboxModule} from '@angular/material/checkbox'; 
import {MatNativeDateModule, MAT_DATE_LOCALE} from '@angular/material/core';
import {MatMomentDateModule} from '@angular/material-moment-adapter';
import {MatSelectModule} from '@angular/material/select';
import {MatCardModule} from '@angular/material/card'; 
import {MatGridListModule} from '@angular/material/grid-list';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AddComponent} from './add.component';

@NgModule({
  declarations: [AddComponent],
  providers: [
    {provide: MAT_DATE_LOCALE, useValue: 'es-MX'}
  ],
  imports: [
    CommonModule,
    FormsModule,
    MatSelectModule,
    MatFormFieldModule,
    MatCardModule,
    MatNativeDateModule,
    MatCheckboxModule,
    MatMomentDateModule,
    MatDatepickerModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatGridListModule,
    MatInputModule,
    RouterModule.forChild([
      {
        path: '',
        component: AddComponent
      }
    ])
  ],
  exports:[
  ]
})
export class AddModule {}