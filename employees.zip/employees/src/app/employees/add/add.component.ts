import {Component, OnInit} from '@angular/core';
import {EmployeesService} from '../../services/employees.service';
import {IdenDocTypeService} from '../../services/iden-doc-type.service';
import {JobAreaService} from '../../services/job-area.service';
import {JobCountryService} from '../../services/job-country.service';
import {IdenDocType} from '../../interfaces/IdenDocType';
import {JobArea} from '../../interfaces/JobArea';
import {JobCountry} from '../../interfaces/JobCountry';
import {NotificationsService} from '../../notifications/notifications.service';
import {InterceptorErrorService} from '../../error/interceptor-error.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import * as moment from 'moment';

const formatDate = "DD/MM/YYYY HH:mm:ss"
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD-MM-YYYY',
    monthYearLabel: 'YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  public saving = false;
  public _tmpDate = Date;
  public mail = '';
  public minDate: Date;
  public maxDate: Date;
  public form: FormGroup;
  public upperCase: string;
  public IDEN_DOC_TYPES: IdenDocType[] = [];
  public JOB_COUNTRY: JobCountry[] = [];
  public JOB_AREA: JobArea[] = [];

  constructor(
    private notification: NotificationsService,
    private interceptorError: InterceptorErrorService,
    private employeesService: EmployeesService,
    private idenDocTypeService: IdenDocTypeService,
    private jobAreaService: JobAreaService,
    private jobCountryService: JobCountryService,
    private _FB: FormBuilder) {
  }

  ngOnInit(): void {
    this.initializeForm();
    const currentDate = new Date();
    this.minDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, currentDate.getDate());
    this.maxDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
    this.findIdenDocTypes();
    this.findJobCountry();
    this.findJobArea();
  }
  initializeForm() {
    this.form = this._FB.group({
      'lastName': ['', [Validators.required, Validators.pattern('[A-Z ]*')]],
      'firstName': ['', [Validators.required, Validators.pattern('[A-Z ]*')]],
      'otherName': ['', [Validators.pattern('[A-Z ]*')]],
      'secondName': ['', [Validators.required, Validators.pattern('[A-Z ]*')]],
      'idIdentityDocumentType': ['', Validators.required],
      'idJobArea': ['', Validators.required],
      'idJobCountry': ['', Validators.required],
      'identification': ['', [Validators.required, Validators.pattern('[a-zA-Z0-9]*')]],
      'email': [{value: '', disabled: false}],
      'dateEntry': ['', Validators.required],
      'state': [{value: true, disabled: false}],
      'registrationDate': [{value: moment(new Date()).format(formatDate), disabled: false}, Validators.required]
    });
  }

  add(): void {
    this.employeesService.add(this.form.value).subscribe(response => {
      this.initializeForm();
      this.notification.successNotification(response['Creado'], 'Registro exitoso');
    }, err => {
      this.interceptorError.handleError(err);
    });
  }

  async findIdenDocTypes() {
    this.idenDocTypeService.findAll().subscribe(idenDocTypes => {
      this.IDEN_DOC_TYPES = idenDocTypes;
    }, err => {
      this.interceptorError.handleError(err);
    });
  }

  async findJobCountry() {
    this.jobCountryService.findAll().subscribe(jobCountries => {
      this.JOB_COUNTRY = jobCountries;
    }, err => {
      this.interceptorError.handleError(err);
    });
  }

  async findJobArea() {
    this.jobAreaService.findAll().subscribe(jobAreas => {
      this.JOB_AREA = jobAreas;
    }, err => {
      this.interceptorError.handleError(err);
    });
  }

  forceUppercase(formControlName: any, event: any) {
    this.form.get(formControlName).setValue(event.target.value.toUpperCase());
  }

  generateEmail() {
    if (this.form.controls['lastName'].status === 'VALID' &&
      this.form.controls['firstName'].status === 'VALID' &&
      this.form.controls['idJobCountry'].status === 'VALID') {

      var domain = '';
      if (this.form.controls['idJobCountry'].value === 1) {
        domain = '.com.co';
      } else if (this.form.controls['idJobCountry'].value === 2) {
        domain = '.com.us';
      }
      this.mail = this.form.controls['firstName'].value.trim() + '.' +
        this.form.controls['lastName'].value.replace(' ', '') + '@cidenet' + domain;

      this.employeesService.generateEmail(this.mail.toLowerCase()).toPromise().then(response => {
        this.form.controls['email'].setValue(response['emailGenerated']);
      }).catch(console.log);
    }
  }

  findByIdentifNumAndIdentifType() {
    this.saving = true;
    var data = this.form.controls['identification'].value + '@' +
      this.form.controls['idIdentityDocumentType'].value;
    this.employeesService.findByIdentifNumAndIdentifType(data).toPromise().then(response => {
      if (!response['identificacionDuplicada']) {
        this._tmpDate = this.form.controls['registrationDate'].value;
        this.form.controls['registrationDate'].setValue(new Date(this._tmpDate.toString()));
        this.add();
      }
    }).catch(console.log);
  }

}
