import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatButtonModule} from '@angular/material/button';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatListModule} from '@angular/material/list';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {HttpClientModule} from '@angular/common/http';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatFormFieldModule} from '@angular/material/form-field';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {EmployeesModule} from './employees/employees.module';
import {AddModule} from './employees/add/add.module';
import {EmployeesService} from './services/employees.service';
import {IdenDocTypeService} from './services/iden-doc-type.service';
import {InterceptorErrorService} from './error/interceptor-error.service';
import {NotificationsService} from './notifications/notifications.service';

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    MatInputModule,
    MatSnackBarModule,
    MatSidenavModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatFormFieldModule,
    EmployeesModule,
    AddModule,
    BrowserAnimationsModule
  ],
  providers: [
    EmployeesService,
    IdenDocTypeService,
    InterceptorErrorService,
    NotificationsService
  ],
  exports: [

  ],

  bootstrap: [AppComponent]
})
export class AppModule {}
