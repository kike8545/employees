import {Injectable} from '@angular/core';
import {MatSnackBar} from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {

  constructor(private _snackBar: MatSnackBar) {}

  /**
    * Metodo con la notificacion de exitosa
    */
  public async successNotification(succesName: string, successMessage: string) {

    this._snackBar.open(successMessage, succesName, {
      duration: 6000,
    });
  }

  /**
   * Metodo con la notificacion de error
   */
  public async errorNotification(errorName: string, errorMessage: string) {

    this._snackBar.open(errorMessage, errorName, {
      duration: 6000,
    });

  }
}
