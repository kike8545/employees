import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {JobArea} from '../interfaces/JobArea';

@Injectable({
  providedIn: 'root'
})
export class JobAreaService {
  constructor(private http: HttpClient) {}
  private url = 'http://localhost:8080/jobArea/';

  findAll(): Observable<JobArea[]> {
    return this.http.get<JobArea[]>(`${this.url}`);
  }
}
