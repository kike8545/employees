import {Injectable} from '@angular/core';
import {Observable, of} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {JobCountry} from '../interfaces/JobCountry';

@Injectable({
  providedIn: 'root'
})
export class JobCountryService {
  constructor(private http: HttpClient) {}
  private url = 'http://localhost:8080/jobCountry/';

  findAll(): Observable<JobCountry[]> {
    return this.http.get<JobCountry[]>(`${this.url}`);
  }
}
