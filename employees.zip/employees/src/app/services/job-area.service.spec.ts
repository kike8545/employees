import { TestBed } from '@angular/core/testing';

import { JobAreaService } from './job-area.service';

describe('JobAreaService', () => {
  let service: JobAreaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JobAreaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
