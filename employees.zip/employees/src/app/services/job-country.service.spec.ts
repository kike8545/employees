import { TestBed } from '@angular/core/testing';

import { JobCountryService } from './job-country.service';

describe('JobCountryService', () => {
  let service: JobCountryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JobCountryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
