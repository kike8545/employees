import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Employees} from '../interfaces/Employees';
import {EmployeesDTO} from '../interfaces/EmployeesDTO';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {

  constructor(private http: HttpClient) {}
  private url = 'http://localhost:8080/employees/';

  add(form: any): Observable<Employees[]> {
    return this.http.post<Employees[]>(`${this.url}`, form, {responseType: 'json'});
  }

  findAll(): Observable<EmployeesDTO[]> {
    return this.http.get<EmployeesDTO[]>(`${this.url}`);
  }

  generateEmail(email: string): Observable<Object> {
    return this.http.get<Object>(`${this.url}` + 'generateEmail/' + email);
  }

  findByIdentifNumAndIdentifType(data: string): Observable<string> {
    return this.http.post<string>(`${this.url}` + 'findByIdentifNumAndIdentifType', data, {responseType: 'json'});
  }

}
