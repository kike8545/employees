export interface EmployeesDTO {
  id: number;
  idIdentityDocumentType: number;
  identDocTypeName: string;
  idJobCountry: number;
  jobCountryName: string;
  firstName: string;
  lastName: string;
  secondName: string;
  otherName: string;
  identification: number;
  active: boolean;
  creation_date: Date;
  email: string;
  dateEntry: Date;
  state: boolean;
}
