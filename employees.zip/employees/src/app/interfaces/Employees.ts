export interface Employees {
  id: number;
  idIdentityDocumentType: number;
  idJobArea: number;
  idJobCountry: number;
  firstName: string;
  lastName: string;
  secondName: string;
  otherName: string;
  identification: number;
  active: boolean;
  creation_date: Date;
  email: string;
  dateEntry: Date;
  state: boolean;
  registrationDate: Date;
}
