export interface JobCountry {
  id: number;
  country: string;
}
