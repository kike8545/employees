export interface JobArea {
  id: number;
  name: string;
}
